"""e-puck controller."""

# You may need to import some classes of the controller module. Ex:
#  from controller import Robot, Motor, DistanceSensor
from controller import Robot, DistanceSensor, Motor
import math
# create the Robot instance.
robot = Robot()

# get the time step of the current world.
timestep = 16
MAX_SPEED = 6.28
w =  1*MAX_SPEED
dist_sensor_max = 255
L = 52 # axle length in mm
R = 20 # wheel radius in mm

#Initialising motors
leftMotor = robot.getMotor('left wheel motor')
rightMotor = robot.getMotor('right wheel motor')
leftMotor.setPosition(float('inf'))
rightMotor.setPosition(float('inf'))
leftMotor.setVelocity(0.0)
rightMotor.setVelocity(0.0)

#Initialising Proximity Sensors
psNames = [
    'ps0', 'ps1', 'ps2', 'ps3',
    'ps4', 'ps5', 'ps6', 'ps7'
]
ps = []
for i in range(8):
    ps.append(robot.getDistanceSensor(psNames[i]))
    ps[i].enable(timestep)

#GO STRAIGHT
def go_straight(w): 
    leftMotor.setVelocity(w)
    rightMotor.setVelocity(w)

#GO RIGHT
def soft_right(v,t):
    leftMotor.setVelocity(v)
    rightMotor.setVelocity(-v)
    robot.step(int(t))

#GO LEFT
def soft_left(v,t):
    leftMotor.setVelocity(-v)
    rightMotor.setVelocity(v)
    robot.step(int(t))

# Main loop:
# - perform simulation steps until Webots is stopping the controller
while robot.step(timestep) != -1:
    psValues = []
    
    for i in range(8):
        psValues.append(ps[i].getValue())
        
    print("psValues[0] :", psValues[0], "psValues[7]:", psValues[7])
    if psValues[0] >= 55.0:
        soft_left(w,1630)
    elif psValues[7]>= 55.0:
    	soft_right(w,1630)
    else:
        go_straight(w)